
public class Details 
{

	public static void main(String[] args) 
	{
		
		// Q2		
		System.out.println("Harry");
		System.out.println("6 Lockey Croft");
		System.out.println("20");
		System.out.println("0190758188");
						
	}

}
