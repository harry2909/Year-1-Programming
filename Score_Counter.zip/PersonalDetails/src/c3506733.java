import java.util.Scanner;

public class c3506733 {

public static void main(String[] args) {
			    
		Scanner input = new Scanner (System.in);
		
		String[] homeTeam = new String[10];
		int[] homeScore = new int[10];
		String[] awayTeam = new String[10];
		int[] awayScore = new int [10];
		int index;
		int totalmatches = 0;
		int totalhome = 0;
		int totalaway = 0;
		int draw = 0;
		int highHscore = 0;
		int highAscore = 0;
		index = 0; //Index represents current value.
		String hscore;
		String ascore;
				
		//Setting loop
		//Input loop
		for(index = 0; index < 10; index++)
		{
			System.out.print("Enter Home Team name or 'exit' to stop: ");
			homeTeam[index] = input.nextLine();
			if(homeTeam[index].equals("exit"))
			{
				break;
				
			}
			
			System.out.print("Enter Home Team score: ");
			hscore = input.nextLine();
			homeScore[index] = Integer.valueOf(hscore);
			
								
			System.out.print("Enter Away Team name: ");
			awayTeam[index] = input.nextLine();
			if(awayTeam[index].equals("exit"))
			{	
				break;
			
			}
			System.out.print("Enter Away Team score: ");
			ascore = input.nextLine();
			awayScore[index] = Integer.valueOf(ascore);
			totalmatches++;
			
			
			totalaway = totalaway + awayScore[index];
			totalhome = totalhome + homeScore[index];			
			
			if(homeScore[index]==awayScore[index]) 
				{draw++;//Goes through each iteration. With each draw, "draw" get's 1 added to it.
			}
			
			if(homeScore[index] > highHscore)//Condition
			{highHscore = homeScore[index];//Current homeScore value is compared to the highest homeScore value. If its higher its saved. If not its discarded.
			
			}
			
			if(awayScore[index] > highAscore)
			{highAscore = awayScore[index];}			
					
		}
		//Displaying contents of the array
			
		for(index = 0; index < totalmatches; index++) //Displays the values stored in each array. Index++ uses increments to repeat the loop trough each index.
		{
			System.out.println(homeTeam[index] + " " + "[" + homeScore[index]  + "]" + " " + "|" + " " + awayTeam[index] + " " + "[" + awayScore[index] + "]" + " ");
			}
			
			System.out.println("Totals ");
			System.out.println("-----------------------");
			System.out.println("Total Home Team Score: " + totalhome);
			System.out.println("Total Away Team Score: " + totalaway);
			System.out.println("Total draws: " + draw);
			System.out.println("Highest home score: " + highHscore);
			System.out.println("Highest home score: " + highAscore);
		
		
				
			}
}

		






		
