
public class Details2
{

	public static void main(String[] args) 
	{
	//Q4-Q5
	String name;
	String address;
	String phonenumber;
	String coursetitle;
	String studentid;
	int age;                                                                        
					
	name = "Harry";
	address = "Lockey Croft";
	phonenumber = "01904758188";
	coursetitle = "Computing";
	studentid = "33506733";
	age = 20;
					
	System.out.println(name);
	System.out.println(address);
	System.out.println(phonenumber);
	System.out.println(coursetitle);
	System.out.println(studentid);
	System.out.println(age);
	
	}
}
